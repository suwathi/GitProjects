package com.bank.service.model;

import java.util.ArrayList;
import java.util.List;

public class CustomerList {
	
	private List<customer> customers;

    public List<customer> getCustomers() {
		return customers;
	}

	public void setCustomers(List<customer> customers) {
		this.customers = customers;
	}

	public CustomerList() {
    	customers = new ArrayList<>();
    }

}
