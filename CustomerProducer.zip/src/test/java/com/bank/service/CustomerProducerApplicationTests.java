package com.bank.service;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerProducerApplicationTests {

	//@Test
	void contextLoads() {
	}

}
